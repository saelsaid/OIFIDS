clear
N=30;
MaxT=500;
S=10;
d = 4; % maximum Decision Tree (DT) depth 
lmt = ones(d,1)*[-32,32];   % constraints
data=importdata('NSL-KDD/KDDTrain-21.txt');
ADLabels=data(:,end);
Data=data(:,1:end-1);
OData=ERHHO(Data,lmt,N,MaxT,S);
% Concept drift
% incCDDetector = incrementalConceptDriftDetector("ddm",Alternative="less",WarmupPeriod=100);
% for i = 1:length(OData)
    %incCDDetector = detectdrift(incCDDetector,OData(i)); 
    %statusname(i) = string(incCDDetector.DriftStatus);
    %optmean(i) = incCDDetector.OptimalMean;
    %optstddev(i) = incCDDetector.OptimalStandardDeviation;
    %if incCDDetector.DriftDetected
       %status(i) = 2;
       %incCDDetector = reset(incCDDetector); % If drift detected, reset the detector 
       %OData=ERHHO(OData,lmt,N,MaxT,S);
    %end
%end

rounds = 10; % rounds of repeat
NumTree = 100; % number of isolation trees
NumSub = 256; % subsample size
NumDim = size(OData, 2); % do not perform dimension sampling 
auc = zeros(rounds, 1);
mtime = zeros(rounds, 2);
rseed = zeros(rounds, 1);
for r = 1:rounds
    disp(['rounds ', num2str(r), ':']);
    rseed(r) = sum(100 * clock);
    Forest = OIF(OData, NumTree, NumSub, NumDim, rseed(r));
    mtime(r, 1) = Forest.ElapseTime;
    [Mass, ~] = IsolationEstimation(OData, Forest);
    Score = - mean(Mass, 2);
    auc(r) = Measure_AUC(Score, ADLabels);
    disp(['auc = ', num2str(auc(r)), '.']);
end
AUC_results = [mean(auc), std(auc)] % average AUC over 10 trials
[Xlog,Ylog,Tlog,AUClog] = perfcurve(logical(ADLabels),Score,'true');
plot(Xlog,Ylog) 
xlabel('False positive rate'); ylabel('True positive rate');
title('AUC')