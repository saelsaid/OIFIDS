function [Mass, ElapseTime] = IsolationEstimation(TestData, Forest)
%     TestData: test data; nt x d matrix; nt: # of test instance; d: dimension;
%     Forest: isolation forest model;
% O/p
%     Mass: nt x NumTree matrix; mass of test instances;
%     ElapseTime: elapsed time;
NumInst = size(TestData, 1);
Mass = zeros(NumInst, Forest.NumTree);
et = cputime;
for k = 1:Forest.NumTree
    Mass(:, k) = IsolationMass(TestData, 1:NumInst, Forest.Trees{k, 1}, zeros(NumInst, 1));
end
ElapseTime = cputime - et;
